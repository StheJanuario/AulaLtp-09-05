package atv1Professor;
public class App {
    public static void main(String[] args) throws Exception {
        Jogador jogador1;
        jogador1 = new Jogador();
        jogador1.setPontuacao(100);
        jogador1.setNome("Jonas");
        jogador1.setAtivado(true);

        System.out.println("Nome:" + jogador1.getNome());
        System.out.println("Pontuacao: " +jogador1.getPontuacao());
        System.out.println("Ativado?: " + jogador1.isAtivado());
        
    }
}
