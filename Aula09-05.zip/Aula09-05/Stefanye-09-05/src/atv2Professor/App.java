package atv2Professor;

public class App {
    public static void main(String[] args) {
        Produto prod1 = new Produto( 0001, 1000.99, "PC da Intel");

        ItemPedido itemPedido = new ItemPedido(prod1, 5);
       
        Pedido meuPedido = new Pedido();
        meuPedido.adicionarItem(itemPedido);
        System.out.println("Total do pedido"+meuPedido.obterTotal());


    }
}
